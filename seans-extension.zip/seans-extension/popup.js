const SEANS = 'https://stafilk2002.github.io/seans/';
const SEANS_TABS = ['https://stafilk2002.github.io/seans/*', 'http://127.0.0.1:8080/*'];
const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function toast(t) { const d = document.createElement('div'); d.className = 'toast'; d.textContent = t; document.body.append(d); setTimeout(() => d.remove(), 2200); }

// ссылка для «Сеанса»: поток + откуда он грузился (нужно некоторым видеосерверам)
function shareUrl(it) { return it.ref && !it.url.includes('#') ? it.url + '#seans-ref=' + encodeURIComponent(it.ref) : it.url; }

async function send(url, title) {
  const tabs = await chrome.tabs.query({ url: SEANS_TABS });
  if (tabs.length) {
    const t = tabs.find(x => x.active) || tabs[tabs.length - 1];
    try { await chrome.tabs.sendMessage(t.id, { type: 'load', url, title }); } catch { await navigator.clipboard.writeText(url).catch(() => {}); toast('Обновите вкладку «Сеанса»; ссылка скопирована'); return; }
    await chrome.tabs.update(t.id, { active: true }); await chrome.windows.update(t.windowId, { focused: true });
    window.close();
  } else {
    await chrome.storage.local.set({ pending: { url, title, ts: Date.now() } });
    await chrome.tabs.create({ url: SEANS });
    window.close();
  }
}
async function copy(url) { try { await navigator.clipboard.writeText(url); toast('Ссылка скопирована'); } catch { prompt('Скопируйте ссылку:', url); } }

function guessQuality(url) { const m = url.match(/(?:^|[\/_\-.])(2160|1440|1080|720|480|360|240)p?(?=[\/_\-.]|$)/i); return m ? m[1] + 'p' : ''; }
async function inspectHls(it) {
  try {
    const r = await fetch(it.url, { credentials: 'omit' }); if (!r.ok) return '';
    const t = await r.text();
    if (!t.includes('#EXTM3U')) return '';
    const hs = [...t.matchAll(/RESOLUTION=\d+x(\d+)/g)].map(m => +m[1]);
    if (t.includes('#EXT-X-STREAM-INF')) { it.master = true; const u = [...new Set(hs)].sort((a, b) => b - a); return u.length ? 'качества: ' + u.map(h => h + 'p').join(', ') : 'несколько качеств'; }
    it.single = true;
    const dur = [...t.matchAll(/#EXTINF:([\d.]+)/g)].reduce((s, m) => s + +m[1], 0);
    return dur ? 'одно качество · ' + Math.round(dur / 60) + ' мин' : 'одно качество';
  } catch { return ''; }
}

(async () => {
  const qt = +new URLSearchParams(location.search).get('tab');   // для проверки: popup.html?tab=ID
  const [tab] = qt ? [await chrome.tabs.get(qt)] : await chrome.tabs.query({ active: true, currentWindow: true });
  $('#pageTitle').textContent = tab ? (tab.title || tab.url) : '';
  const list = $('#list');
  if (!tab) return;
  let host = ''; try { host = new URL(tab.url).hostname; } catch {}

  // YouTube и VK «Сеанс» понимает по обычной ссылке на страницу
  if (/(^|\.)(youtube\.com|youtu\.be|vk\.com|vk\.ru|vkvideo\.ru)$/.test(host) && /(watch|shorts|youtu\.be\/|video-?\d+_\d+|clip-?\d+_\d+|z=video)/.test(tab.url)) {
    const name = /vk/.test(host) ? 'VK Видео' : 'YouTube';
    list.innerHTML = `<div class="item best"><div class="top"><span class="badge page">${name}</span><span class="best-lbl">подходит</span></div>
      <div class="host">${esc(tab.title || '')}</div><div class="meta">«Сеанс» понимает ссылку на эту страницу напрямую.</div>
      <div class="row"><button class="primary" id="pg">Включить в Сеансе</button><button id="pgc">Копировать</button></div></div>`;
    $('#pg').onclick = () => send(tab.url, tab.title); $('#pgc').onclick = () => copy(tab.url);
    return;
  }

  const v = await chrome.runtime.sendMessage({ type: 'list', tabId: tab.id });
  let items = (v && v.items) || [];
  if (v && v.drm && !items.length) {
    list.innerHTML = `<div class="warn">Этот сайт защищает видео (DRM) — так делают Кинопоиск, Okko, Иви, Netflix и другие платные сервисы. Достать ссылку и смотреть его через «Сеанс» не получится.</div>`;
    return;
  }
  if (!items.length) {
    list.innerHTML = `<div class="empty"><b>Пока ничего не найдено</b>Расширение видит видео, только когда оно начало загружаться.
      <ol><li>Нажмите ▶ в плеере на этой странице.</li><li>Подождите 2–3 секунды (рекламу можно не досматривать).</li><li>Снова нажмите на значок «Сеанса».</li></ol></div>`;
    return;
  }
  items = items.filter(i => i.type !== 'dash').concat(items.filter(i => i.type === 'dash'));
  await Promise.all(items.map(async it => { it.q = it.type === 'hls' ? await inspectHls(it) : guessQuality(it.url); }));
  // Лучший вариант — «главный» плейлист со всеми качествами. Если сервер не дал его проверить,
  // считаем главным тот, что плеер загрузил первым (плееры всегда начинают с него).
  items.forEach((it, i) => it.idx = i);
  const score = it => it.type === 'hls'
    ? (it.master ? 300 : it.single ? 170 : 220 + (/master|index|playlist|manifest/i.test(it.url) ? 30 : 0) - it.idx)
    : it.type === 'video' ? 150 - it.idx : 0;
  items.sort((a, b) => score(b) - score(a));
  list.innerHTML = '';
  items.forEach((it, i) => {
    let h = ''; try { h = new URL(it.url).hostname; } catch {}
    const best = i === 0 && it.type !== 'dash';
    const badge = { hls: 'Поток', video: 'Видео', dash: 'DASH' }[it.type];
    const d = document.createElement('div'); d.className = 'item' + (best ? ' best' : '');
    d.innerHTML = `<div class="top"><span class="badge ${it.type}">${badge}</span>${it.q ? `<span class="q">${esc(it.q)}</span>` : ''}${best ? '<span class="best-lbl">лучший вариант</span>' : ''}</div>
      <div class="host">${esc(h)}</div><div class="meta" title="${esc(it.url)}">${esc(it.url)}</div>` +
      (it.type === 'dash' ? `<div class="meta">Формат DASH «Сеанс» пока не воспроизводит — выберите другой вариант или озвучку на сайте.</div>` :
      `<div class="row"><button class="primary">Включить в Сеансе</button><button class="cp">Копировать</button></div>`);
    if (it.type !== 'dash') { d.querySelector('.primary').onclick = () => send(shareUrl(it), tab.title); d.querySelector('.cp').onclick = () => copy(shareUrl(it)); }
    list.append(d);
  });
})();
