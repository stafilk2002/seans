// «Сеанс — ссылка на видео»: фоновый скрипт.
// Смотрит, какие видеопотоки страница загружает (во всех фреймах, включая
// встроенные плееры других сайтов), и запоминает их для вкладки.

const SEANS_HOSTS = ['stafilk2002.github.io', '127.0.0.1'];
const SKIP_HOSTS = /(^|\.)(doubleclick\.net|googlesyndication\.com|googleadservices\.com|google-analytics\.com|yandex\.(ru|net)|mc\.yandex|adfox|adriver|betweendigital|mail\.ru|ok\.ru\/dk|youtube\.com|googlevideo\.com|ytimg\.com|vk\.com|vk\.ru|vkvideo\.ru|vkuser\.net|userapi\.com|vk-cdn\.net|okcdn\.ru)$/i;
const SEGMENT = /(\.(ts|m4s|aac|m4a|vtt|srt|key|jpg|jpeg|png|webp|gif|js|css|json)(\?|$))|([\/_-](seg|segment|chunk|frag|fragment|init)[-_]?\d*[\/._-])|([?&](range|bytes)=)/i;

const key = tabId => 't' + tabId;
async function getList(tabId) { const r = await chrome.storage.session.get(key(tabId)); return r[key(tabId)] || { items: [], drm: false, page: '' }; }
async function setList(tabId, v) { await chrome.storage.session.set({ [key(tabId)]: v }); badge(tabId, v); }
function badge(tabId, v) {
  const n = v.items.length;
  chrome.action.setBadgeBackgroundColor({ tabId, color: n ? '#30d158' : '#8e8e93' }).catch(() => {});
  chrome.action.setBadgeText({ tabId, text: n ? String(n) : (v.drm ? '!' : '') }).catch(() => {});
}

function classify(url, contentType) {
  let u; try { u = new URL(url); } catch { return null; }
  if (!/^https?:$/.test(u.protocol)) return null;
  if (SEANS_HOSTS.includes(u.hostname) || SKIP_HOSTS.test(u.hostname)) return null;
  const path = (u.pathname + u.search).toLowerCase();
  const ct = (contentType || '').toLowerCase();
  if (/\.m3u8(\?|$|:)|:hls:manifest/.test(path) || /mpegurl/.test(ct)) return 'hls';
  if (/\.mpd(\?|$)/.test(path) || /dash\+xml/.test(ct)) return 'dash';
  if (SEGMENT.test(path)) return null;
  if (/\.(mp4|webm|mkv|mov|m4v)(\?|$|:|\/)/.test(path) || /^video\/(mp4|webm|x-matroska|quicktime)/.test(ct)) return 'video';
  return null;
}

// одна очередь записи на вкладку, чтобы параллельные запросы не затирали друг друга
const queues = new Map();
function enqueue(tabId, fn) { const p = (queues.get(tabId) || Promise.resolve()).then(fn).catch(() => {}); queues.set(tabId, p); return p; }

function remember(d, type) {
  if (d.tabId < 0) return;
  enqueue(d.tabId, async () => {
    const v = await getList(d.tabId);
    const norm = d.url.replace(/([?&])(range|bytes|_|t|ts)=[^&]*/gi, '$1');
    if (v.items.some(i => i.norm === norm)) return;
    const ref = d.initiator && d.initiator !== 'null' ? d.initiator + '/' : '';
    v.items.push({ url: d.url, norm, type, ref, time: Date.now(), frame: d.frameId });
    if (v.items.length > 40) v.items.shift();
    await setList(d.tabId, v);
  });
}

chrome.webRequest.onBeforeRequest.addListener(d => {
  if (d.tabId < 0) return;
  if (/widevine|playready|fairplay|\/license(\?|\/|$)|drm/i.test(d.url) && !/\.(m3u8|mp4)/i.test(d.url)) {
    enqueue(d.tabId, async () => { const v = await getList(d.tabId); if (!v.drm) { v.drm = true; await setList(d.tabId, v); } });
    return;
  }
  const t = classify(d.url, '');
  if (t) remember(d, t);
}, { urls: ['<all_urls>'], types: ['xmlhttprequest', 'media', 'other', 'sub_frame'] });

// ссылки без расширения в адресе — узнаём по типу ответа
chrome.webRequest.onHeadersReceived.addListener(d => {
  if (d.tabId < 0 || d.statusCode >= 400) return;
  const h = n => { const x = (d.responseHeaders || []).find(x => x.name.toLowerCase() === n); return x ? x.value : ''; };
  const ct = h('content-type'); if (!ct) return;
  if (classify(d.url, '')) return;           // уже учтено по адресу
  const t = classify(d.url, ct); if (!t) return;
  if (t === 'video') { const len = +h('content-length') || 0; const cr = h('content-range'); const total = cr ? +(cr.split('/')[1] || 0) : len; if (total && total < 3e6) return; }
  remember(d, t);
}, { urls: ['<all_urls>'], types: ['xmlhttprequest', 'media', 'other'] }, ['responseHeaders']);

// новая страница во вкладке — начинаем список заново
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status === 'loading' && info.url) enqueue(tabId, () => setList(tabId, { items: [], drm: false, page: info.url }));
});
chrome.tabs.onRemoved.addListener(tabId => chrome.storage.session.remove(key(tabId)));

// Сайт «Сеанс» просит подставить Referer/CORS для потока (многие видеосерверы
// отдают видео только «своему» сайту). Правило действует только на запросы,
// которые делает страница «Сеанса», и только для видео.
const RULE_ID = 1;
async function prepare(ref) {
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: [RULE_ID] });
  if (!ref) return 'cleared';
  let origin; try { origin = new URL(ref).origin; } catch { return 'bad-ref'; }
  await chrome.declarativeNetRequest.updateDynamicRules({
    addRules: [{
      id: RULE_ID, priority: 1,
      condition: {
        initiatorDomains: SEANS_HOSTS,
        excludedRequestDomains: ['jsdelivr.net', 'unpkg.com', 'peerjs.com', 'googleapis.com', 'gstatic.com', 'youtube.com', 'ytimg.com', 'googlevideo.com', 'vk.com', 'vk.ru', 'vkvideo.ru', 'github.io'],
        resourceTypes: ['xmlhttprequest', 'media', 'other'],
      },
      action: {
        type: 'modifyHeaders',
        requestHeaders: [{ header: 'referer', operation: 'set', value: ref }, { header: 'origin', operation: 'set', value: origin }],
        responseHeaders: [{ header: 'access-control-allow-origin', operation: 'set', value: '*' }],
      },
    }],
  });
  return 'ok';
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.type === 'prepare') { prepare(msg.ref).then(r => reply({ ok: true, r }), e => reply({ ok: false, e: String(e) })); return true; }
  if (msg && msg.type === 'list') { getList(msg.tabId).then(reply); return true; }
});
