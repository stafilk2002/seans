// Мостик между расширением и сайтом «Сеанс» (работает только на странице «Сеанса»).
(() => {
  const VERSION = chrome.runtime.getManifest().version;
  document.documentElement.dataset.seansExt = VERSION;
  const hello = () => window.postMessage({ source: 'seans-ext', type: 'hello', version: VERSION }, location.origin);
  hello(); document.addEventListener('DOMContentLoaded', hello);

  // ссылка, отправленная из расширения, пока «Сеанс» не был открыт
  chrome.storage.local.get('pending', r => {
    const p = r && r.pending; if (!p) return;
    chrome.storage.local.remove('pending');
    if (Date.now() - p.ts > 10 * 60 * 1000) return;
    const go = () => setTimeout(() => window.postMessage({ source: 'seans-ext', type: 'load', url: p.url, title: p.title || '' }, location.origin), 300);
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go); else go();
  });

  // расширение → сайт: «включи эту ссылку»
  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (msg && msg.type === 'load') { window.postMessage({ source: 'seans-ext', type: 'load', url: msg.url, title: msg.title || '' }, location.origin); reply({ ok: true }); }
  });

  // сайт → расширение: «подставь заголовки для этого потока»
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.source !== 'seans-page') return;
    const d = e.data;
    if (d.type === 'ping') hello();
    if (d.type === 'prepare') chrome.runtime.sendMessage({ type: 'prepare', ref: d.ref || null }, r => {
      window.postMessage({ source: 'seans-ext', type: 'prepared', id: d.id, ok: !!(r && r.ok) }, location.origin);
    });
  });
})();
